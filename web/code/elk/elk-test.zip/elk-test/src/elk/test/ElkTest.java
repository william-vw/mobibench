package elk.test;

import java.io.File;

import org.semanticweb.elk.owlapi.ElkReasonerFactory;
import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.InferenceType;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;

public class ElkTest extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_elk_test);

		try {
			classifyOntology();

		} catch (OWLOntologyCreationException e) {
			e.printStackTrace();
		}
	}

	private void classifyOntology() throws OWLOntologyCreationException {
		OWLOntologyManager manager = OWLManager.createOWLOntologyManager();

		String path = Environment.getExternalStorageDirectory()
				+ "/Android/data/rdf/galen.owl";

		// Load your ontology
		OWLOntology ont;
		ont = manager.loadOntologyFromOntologyDocument(new File(path));

		Log.d("elk-test", "loaded ontology");

		// Create an ELK reasoner.
		OWLReasonerFactory reasonerFactory = new ElkReasonerFactory();
		OWLReasoner reasoner = reasonerFactory.createReasoner(ont);

		Log.d("elk-test", "created reasoner");

		// Classify the ontology.
		reasoner.precomputeInferences(InferenceType.CLASS_HIERARCHY);

		Log.d("elk-test", "classified ontology");

		// OWLDataFactory factory = manager.getOWLDataFactory();
		// OWLClass subClass = factory
		// .getOWLClass(IRI
		// .create("http://www.co-ode.org/ontologies/galen#AbsoluteShapeState"));
		// OWLAxiom removed = factory
		// .getOWLSubClassOfAxiom(
		// subClass,
		// factory.getOWLClass(IRI
		// .create("http://www.co-ode.org/ontologies/galen#ShapeState")));
		//
		// OWLAxiom added = factory
		// .getOWLSubClassOfAxiom(
		// subClass,
		// factory.getOWLClass(IRI
		// .create("http://www.co-ode.org/ontologies/galen#GeneralisedStructure")));
		// // Remove an existing axiom, add a new axiom
		// manager.addAxiom(ont, added);
		// manager.removeAxiom(ont, removed);
		// // This is a buffering reasoner, so you need to flush the changes
		// reasoner.flush();
		//
		// // Re-classify the ontology, the changes should be accommodated
		// // incrementally (i.e. without re-inferring all subclass
		// relationships)
		// // You should be able to see it from the log output
		// reasoner.precomputeInferences(InferenceType.CLASS_HIERARCHY);

		// Terminate the worker threads used by the reasoner.
		reasoner.dispose();

	}
}
