package rdfonthego.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.List;
import java.util.Vector;

import org.openjena.atlas.lib.StrUtils;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;

import com.hp.hpl.jena.graph.Factory;
import com.hp.hpl.jena.query.Query;
import com.hp.hpl.jena.query.QueryExecution;
import com.hp.hpl.jena.query.QueryExecutionFactory;
import com.hp.hpl.jena.query.QueryFactory;
import com.hp.hpl.jena.query.QuerySolution;
import com.hp.hpl.jena.query.ResultSet;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.Property;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.rdf.model.Statement;
import com.hp.hpl.jena.rdf.model.StmtIterator;

import deri.org.store.BDBGraph;

public class RdfOnTheGoTest extends Activity {

	// private String dataPath = Environment.getExternalStorageDirectory()
	// + "/Android/data/benchmarks/rdf/";
	// private String rulesPath = Environment.getExternalStorageDirectory()
	// + "/Android/data/benchmarks/rules/";

	// for use on emulator
	// private String dataPath = "data/data/benchmarks/rdf/";
	// private String rulesPath = "data/data/benchmarks/rules/";

	private String path = "http://web.cs.dal.ca/~woensel/benchmarks/";
	private String dataPath = path + "data/";
	private String rulesPath = path + "rules/";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rdf_on_the_go_test);

		new Thread(new Runnable() {
			public void run() {
				try {
					// test();
					testOWL2RL();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}).start();

	}

	public void test() throws Exception {
		File file = new File(Environment.getExternalStorageDirectory()
				+ "/Android/data/rdf/data.nt");

		String baseUri = "http://www.dal.ca/nichegroup/impactaf#";

		BDBGraph graph = (BDBGraph) Factory.createBDBGraph("test");
		// graph = new BDBGraph("test"); // ALT

		graph.load(file, baseUri);
		graph.sync();

		Log.d("rdfonthego-test", "loaded data into graph");

		Model model = ModelFactory.creatModelStore("test");
		// model = new ModelCom(graph); // ALT

		Log.d("rdfonthego-test", "created model");

		StmtIterator iter = model.listStatements();
		while (iter.hasNext()) {
			Statement stmt = iter.nextStatement();

			Log.d("rdfonthego-test", stmt.asTriple().toString());
		}

		String queryString = StrUtils.strjoin("\n",
				"PREFIX niche: <http://www.dal.ca/nichegroup/impactaf#>",
				"SELECT ?value {", "?x niche:hasValue ?value .", "}");

		Query query = QueryFactory.create(queryString);
		QueryExecution qExec = QueryExecutionFactory.create(query, model);

		Log.d("rdfonthego-test", "created query & execution plan");

		for (ResultSet itr = qExec.execSelect(); itr.hasNext();) {
			QuerySolution sol = itr.next();

			Log.d("rdfonthego-test", sol.get("value").toString());
		}

		Log.d("rdfonthego-test", "executed query");

		qExec.close();

		model.close();
		graph.close();
	}

	public void testOWL2RL() throws Exception {
//		BDBGraph graph = (BDBGraph) Factory.createBDBGraph("test6");
//		graph.load(dataPath + "owlDemoSchema.nt", "");
//		graph.load(dataPath + "owlDemoData.nt", "");
		// graph.load(new File(dataPath + "owlDemo.nt"),
		// "http://niche.cs.dal.ca/owl/");
//		graph.sync();

		Log.d("rdfonthego-test", "loaded data into graph");
		Model model = ModelFactory.creatModelStore("test6");
		// Model model = new ModelCom(graph);

		testOWL2RL_inf(model);
		testOWL2RL_val(model);

		model.close();
//		graph.close();
	}

	private void testOWL2RL_inf(Model model) throws Exception {
		List<String> rules = readQueries(rulesPath + "owl2rl_inf.sparqlq");
		Model infmodel = ModelFactory.createDefaultModel();

		int prevStmtCnt = countStmts(model);

		boolean hasNewStmts = true;
		while (hasNewStmts) {
			System.out.println("Executing ruleset\n");

			for (String rule : rules) {
				// System.out.println("rule: \n" + rule);

				Query q = QueryFactory.create(rule);
				QueryExecution qe = QueryExecutionFactory.create(q, model);

				Model res = qe.execConstruct(model);
				model.add(res);

				qe.close();

				infmodel.add(res);

				// if (res.listStatements().hasNext()) {
				// System.out.println("results: ");
				// res.write(System.out);
				//
				// } else
				// System.out.println("no results");
				//
				// System.out.println("\n\n");
			}

			int newStmtCnt = countStmts(model);
			System.out.println(newStmtCnt + " - " + prevStmtCnt);

			hasNewStmts = (newStmtCnt > prevStmtCnt);
			prevStmtCnt = newStmtCnt;

			// infmodel.write(System.out, "N3");
			// infmodel = ModelFactory.createDefaultModel();
		}

		System.out.println("\n\ninferences:");
		printStatements(infmodel, null, null, null);

		Resource nForce = model.getResource("urn:x-hp:eg/nForce");
		System.out.println("nForce *:");
		printStatements(model, nForce, null, null);
	}

	private void testOWL2RL_val(Model model) throws Exception {
		Model valmodel = ModelFactory.createDefaultModel();

		List<String> rules = readQueries(rulesPath + "owl2rl_val.sparqlq");
		for (String rule : rules) {
			// System.out.println("rule: \n" + rule);

			Query q = QueryFactory.create(rule);
			QueryExecution qe = QueryExecutionFactory.create(q, model);

			Model res = qe.execConstruct(model);
			valmodel.add(res);
		}

		System.out.println("validation results: \n");
		printStatements(valmodel, null, null, null);
	}

	private int countStmts(Model model) {
		// int nr = 0;
		//
		// Query q =
		// QueryFactory.create("SELECT ?x ?y ?z WHERE { ?x ?y ?z . }");
		// QueryExecution qe = QueryExecutionFactory.create(q, model);
		//
		// ResultSet res = qe.execSelect();
		// while (res.hasNext()) {
		// res.next();
		//
		// nr++;
		// }
		//
		// return nr;

		int nr = 0;
		StmtIterator it = model.listStatements();
		while (it.hasNext()) {
			it.next();

			nr++;
		}

		return nr;
	}

	private List<String> readQueries(String filePath) throws Exception {
		// BufferedReader reader = new BufferedReader(new FileReader(filePath));
		BufferedReader reader = new BufferedReader(new InputStreamReader(
				new URL(filePath).openStream()));

		List<String> queries = new Vector<String>();

		String query = "";
		String line = null;
		while ((line = reader.readLine()) != null) {
			line = line.trim();

			if (line.equals("")) {
				queries.add(query);

				query = "";
			}

			// else if (line.startsWith("#"))
			// continue;

			else
				query += line + "\n";
		}

		if (!query.equals(""))
			queries.add(query);

		reader.close();

		return queries;
	}

	private void printStatements(Model m, Resource s, Property p, Resource o) {
		for (StmtIterator i = m.listStatements(s, p, o); i.hasNext();) {
			Statement stmt = i.nextStatement();
			System.out.println(" - " + stmt);
		}

		System.out.println();
		System.out.println();
	}
}
