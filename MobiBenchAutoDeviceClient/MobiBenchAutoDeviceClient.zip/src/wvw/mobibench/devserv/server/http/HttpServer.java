/**
 * Copyright 2016 William Van Woensel

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
 * 
 * 
 * @author wvw
 * 
 */

package wvw.mobibench.devserv.server.http;

import java.io.IOException;
import java.io.InputStream;

import wvw.mobibench.devserv.server.handler.HandlerException;
import wvw.mobibench.devserv.server.handler.HandlerListener;
import wvw.mobibench.devserv.server.handler.RequestHandler;
import wvw.mobibench.devserv.server.msg.OkMsg;
import wvw.mobibench.devserv.server.msg.ResponseMsg;
import wvw.mobibench.devserv.server.serial.Serializer;
import wvw.utils.IOUtils;
import wvw.utils.log2.Log;
import fi.iki.elonen.NanoHTTPD;
import fi.iki.elonen.NanoHTTPD.Response.Status;

public class HttpServer extends NanoHTTPD implements HandlerListener {

	private RequestHandler handler;
	private Serializer serial = new Serializer();

	public HttpServer(RequestHandler handler, int port) {
		super(port);

		this.handler = handler;
	}

	public Response serve(IHTTPSession session) {
		Method method = session.getMethod();
		String uri = session.getUri();

		try {
			switch (method) {

			case GET:
				return newFixedLengthResponse("<h1>Welcome to AutoBenchmarkDeviceClient!</h1>");

			case POST:
				String data = readBody(session);
				handler.handle(uri, data, this);

				return newFixedLengthResponse(serial.serialize(new OkMsg()));

			default:
				Log.i("unsupported method: " + method);

				return newStatusResponse(Status.METHOD_NOT_ALLOWED,
						"Allow", "POST");
			}

		} catch (HandlerException e) {
			Log.e(e);

			return newErrorResponse(e, session);

		} catch (IOException e) {
			Log.e(e);

			return newErrorResponse(e, session);
		}
	}

	protected String readBody(IHTTPSession session) throws IOException {
		// return IOUtils.readStr(session.getInputStream());

		InputStream in = session.getInputStream();

		StringBuffer sb = new StringBuffer();
		byte[] bytes = new byte[1024];

		int read = 0;
		while ((read = in.read(bytes)) > 0) {
			sb.append(new String(bytes, 0, read));

			if (in.available() == 0)
				break;
		}

		return sb.toString();
	}

	protected Response newErrorResponse(Exception e, IHTTPSession session) {
		Error ret = new Error(e);

		return newFixedLengthResponse(Status.INTERNAL_ERROR,
				NanoHTTPD.MIME_PLAINTEXT, serial.serialize(ret));
	}

	protected static String getOrigin(String url) {
		return url.substring(0, url.indexOf("/"));
	}

	public void response(String url, ResponseMsg message) {
		try {
			IOUtils.sendPost(url, serial.serialize(message));

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}