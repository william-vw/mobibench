package jfact.test;

import java.io.File;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.reasoner.InferenceType;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerConfiguration;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.SimpleConfiguration;

import uk.ac.manchester.cs.jfact.JFactFactory;
import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;

public class JFactTest extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_jfact_test);

		try {
			setUp();

			test();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	OWLReasonerFactory reasonerFactory = null;
	OWLOntology ontology;

	public void setUp() throws OWLOntologyCreationException {
		this.reasonerFactory = new JFactFactory();
		this.ontology = OWLManager
				.createOWLOntologyManager()
				.loadOntologyFromOntologyDocument(
						new File(
								Environment.getExternalStorageDirectory()
										+ "/Android/data/rdf/cinema-service-request.owl"));
		// .loadOntology(
		// IRI.create("http://web.cs.dal.ca/~woensel/rdf/pizza.owl"));
	}

	public void test() throws Exception {
		// a config object. Things like monitor, timeout, etc, go here
		OWLReasonerConfiguration config = new SimpleConfiguration(50000);
		// Create a reasoner that will reason over our ontology and its imports
		// closure. Pass in the configuration.
		OWLReasoner reasoner = this.reasonerFactory.createReasoner(
				this.ontology, config);
		// Ask the reasoner to classify the ontology
		reasoner.precomputeInferences(InferenceType.CLASS_HIERARCHY,
				InferenceType.CLASS_ASSERTIONS,
				InferenceType.OBJECT_PROPERTY_HIERARCHY,
				InferenceType.DATA_PROPERTY_HIERARCHY,
				InferenceType.OBJECT_PROPERTY_ASSERTIONS);
		// We can determine if the ontology is actually consistent (in this
		// case, it should be).

		Log.d("jfact-test", "consistent? " + reasoner.isConsistent());

		// // get a list of unsatisfiable classes
		// Node<OWLClass> bottomNode = reasoner.getUnsatisfiableClasses();
		// // leave owl:Nothing out
		// Set<OWLClass> unsatisfiable = bottomNode.getEntitiesMinusBottom();
		// if (!unsatisfiable.isEmpty()) {
		// Log.d("jfact-test", "The following classes are unsatisfiable: ");
		// for (OWLClass cls : unsatisfiable) {
		// Log.d("jfact-test", cls.getIRI().getFragment());
		// }
		// } else {
		// Log.d("jfact-test", "There are no unsatisfiable classes");
		// }
		// // Look up and print all direct subclasses for all classes
		// for (OWLClass c : this.ontology.getClassesInSignature()) {
		// // the boolean argument specifies direct subclasses; false would
		// // specify all subclasses
		// // a NodeSet represents a set of Nodes.
		// // a Node represents a set of equivalent classes
		// NodeSet<OWLClass> subClasses = reasoner.getSubClasses(c, true);
		// for (OWLClass subClass : subClasses.getFlattened()) {
		// Log.d("jfact-test", subClass.getIRI().getFragment()
		// + " subclass of " + c.getIRI().getFragment());
		// }
		// }
		// // for each class, look up the instances
		for (OWLClass c : this.ontology.getClassesInSignature()) {
			// the boolean argument specifies direct subclasses; false would
			// specify all subclasses
			// a NodeSet represents a set of Nodes.
			// a Node represents a set of equivalent classes/or sameAs
			// individuals
			NodeSet<OWLNamedIndividual> instances = reasoner.getInstances(c,
					true);
			for (OWLNamedIndividual i : instances.getFlattened()) {
				Log.d("jfact-test", i.getIRI().getFragment() + " instance of "
						+ c.getIRI().getFragment());
				// look up all property assertions
				for (OWLObjectProperty op : this.ontology
						.getObjectPropertiesInSignature()) {
					NodeSet<OWLNamedIndividual> petValuesNodeSet = reasoner
							.getObjectPropertyValues(i, op);
					for (OWLNamedIndividual value : petValuesNodeSet
							.getFlattened()) {
						Log.d("jfact-test", i.getIRI().getFragment() + " "
								+ op.getIRI().getFragment() + " "
								+ value.getIRI().getFragment());
					}
				}
			}
		}
	}
}
