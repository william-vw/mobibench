/** Automatically generated file. DO NOT MODIFY */
package rdfonthego.test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}