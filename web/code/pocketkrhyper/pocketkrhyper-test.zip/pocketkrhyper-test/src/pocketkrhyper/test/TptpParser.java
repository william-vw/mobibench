/*
 * TptpParser.java
 *
 * Created on 15. November 2004, 14:58
*
 * Pocket KrHyper - 
 * an automated theorem proving library for the 
 * Java 2 Platform, Micro Edition (J2ME)
 * Copyright (C) 2005 Thomas Kleemann and Alex Sinner
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. 
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
 *
 */

package pocketkrhyper.test;
import pocketkrhyper.reasoner.*;
import pocketkrhyper.reasoner.krhyper.*;
import pocketkrhyper.logic.firstorder.*;
import java.io.*;


/**
 *
 * @author  sinner
 * @version $Name:  $ $Revision: 1.1 $
 * @todo implementation
 * @todo documentation
 * @todo unit testing
 */
public class TptpParser {
    
    public static final String read(InputStream in){
        InputStreamReader reader = new InputStreamReader(in);
        int c;
        StringBuffer readBuffer = new StringBuffer();
        try {
            while (( c = reader.read()) != -1){
                readBuffer.append((char)c);
            }
        } catch (IOException e){
            throw new RuntimeException("Failed Reading InputStream");
        } finally {
            try {
                in.close();
            } catch (IOException e){
                throw new RuntimeException("Failed Closing InputStream");
            }
            
        }
        return readBuffer.toString();
    }
    
    public static final KnowledgeBase parse(InputStream in){
        KnowledgeBase kb = new KnowledgeBase();
        InputStreamReader reader = new InputStreamReader(in);
        int c;
        StringBuffer clause = new StringBuffer();
        boolean comment = false;
        try {
            while (( c = reader.read()) != -1){
                switch ((char)c){
                    case '%':
                        comment = true;
                        break;
                    case '.':
                        if (!comment){
                            clause.append((char)c);
                            kb.addClause(LogicFactory.newClause(clause.toString()));
                            clause.setLength(0); //delete the old stuff
                        }
                        break;
                    case ' '://ignore spaces
                        break;
                    case '\n'://ignore newlines, but unset comment flag
                        comment = false;
                        break;
                    default:
                        if (!comment){
                            clause.append((char)c);
                        }
                }
            }
        } catch (IOException e){
            throw new RuntimeException("Failed Reading InputStream");
        } finally {
            try {
                in.close();
            } catch (IOException e){
                throw new RuntimeException("Failed Closing InputStream");
            }
            
        }
        return kb;
    }
    
}
