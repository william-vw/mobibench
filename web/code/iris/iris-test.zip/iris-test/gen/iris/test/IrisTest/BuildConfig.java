/** Automatically generated file. DO NOT MODIFY */
package iris.test.IrisTest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}