package pocketkrhyper.test;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;

import pocketkrhyper.logic.firstorder.KnowledgeBase;
import pocketkrhyper.reasoner.ProofNotFoundException;
import pocketkrhyper.reasoner.Reasoner;
import pocketkrhyper.reasoner.krhyper.KrHyper;
import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

import com.example.pocketkrhyperse.R;

public class PocketKRHyperTest extends Activity {

	private KnowledgeBase kb;
	private Reasoner reasoner;

	private final static String version = "0.8";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pocket_krhyper_test);

		kb = new KnowledgeBase();
		reasoner = new KrHyper();
		
		int minTermWeight = 2;
		int maxTermWeight = 0;
		int timeout = 1000;
		String fileName = "tptp/PUZ/PUZ001-3.tme";

		String[] args = new String[0];

		InputStream in = null;
		for (int i = 0; i < args.length; i++) {
			if (args[i].equalsIgnoreCase("-minTermWeight")) {
				i++;
				try {
					minTermWeight = Integer.parseInt(args[i]);
				} catch (Exception ex) {
					Log.d("pocketkrhyper-test", getUsage());
					// System.exit(-1);
				}
			} else if (args[i].equalsIgnoreCase("-maxTermWeight")) {
				i++;
				try {
					maxTermWeight = Integer.parseInt(args[i]);
				} catch (Exception ex) {
					Log.d("pocketkrhyper-test", getUsage());
					// System.exit(-1);
				}
			} else if (args[i].equalsIgnoreCase("-timeout")) {
				i++;
				try {
					timeout = Integer.parseInt(args[i]);
				} catch (Exception ex) {
					Log.d("pocketkrhyper-test", getUsage());
					// System.exit(-1);
				}
			} else {
				fileName = args[i];
			}
		}

		try {
			in = getAssets().open(fileName);
		} catch (IOException e) {
			e.printStackTrace();
		}

		// try {
		// if (fileName != null) {
		// in = new FileInputStream(fileName);
		// } else {
		// Log.d("pocketkrhyper-test", getUsage());
		// System.exit(-1);
		// }
		// } catch (FileNotFoundException ex) {
		// Log.d("pocketkrhyper-test", "Could not open file " + fileName);
		// System.exit(-1);
		// }

		try {
			openTPTPProblem(in);
		} catch (IOException ex) {
			Log.d("pocketkrhyper-test", "Could not read file " + fileName);
			// System.exit(-1);
		}

		Log.d("pocketkrhyper-test",
				"% Running Pocket KrHyper with the following parameters:"
						+ "\n% Version: " + version + "\n% Input File: "
						+ fileName + "\n% minTermWeight: " + minTermWeight
						+ "\n% maxTermWeight: " + maxTermWeight
						+ "\n% timeout: " + timeout + '\n');

		Log.d("pocketkrhyper-test",
				solveProblem(minTermWeight, maxTermWeight, timeout));
		// System.exit(1);
	}

	private final void openTPTPProblem(InputStream in) throws IOException {
		kb = TptpParser.parse(in);
	}

	private final String solveProblem(int minTermWeight, int maxTermWeight,
			int timeout) {
		reasoner.setKnowledgeBase(kb);
		StringBuffer text = new StringBuffer();
		try {
			long currentTime = System.currentTimeMillis();
			boolean model = reasoner.reason(minTermWeight, maxTermWeight,
					timeout);
			long time = System.currentTimeMillis() - currentTime;
			if (model) {
				text.append("% Model found in " + time + "ms:\n");
				for (Enumeration e = reasoner.getModel().elements(); e
						.hasMoreElements();) {
					text.append(e.nextElement().toString());
					text.append(".\n");
				}
			} else {
				text.append("% Refutation found in " + time + "ms.\n");
			}
		} catch (ProofNotFoundException ex) {
			text.append("% No Solution found. (Timeout)\n");
		} catch (Error err) {
			text.append("% No Solution found. (Out of Memory)\n");
		} finally {
			reasoner.interruptReasoner();
		}
		kb = null;
		return text.toString();
	}

	private static final String getUsage() {
		return "Usage:"
				+ "\njava -jar PocketKrHyper.jar [-minTermWeight n] [-maxTermWeight m] [-timeout ms] PROTEINproblem"
				+ "\nwhere \n\t n is the minimum term weight (default 2)"
				+ "\n\t m is the maximum term weight (has to be 0 or > n). 0 means no upper bound is given. Default 0."
				+ "\n\t ms the timeout for the proof procedure in ms. Default 1000."
				+ "\n\t PROTEINproblem - a deduction problem in PROTEIN syntax.\n";

	}
}
