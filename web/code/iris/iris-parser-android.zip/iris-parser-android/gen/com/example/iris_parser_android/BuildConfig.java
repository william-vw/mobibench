/** Automatically generated file. DO NOT MODIFY */
package com.example.iris_parser_android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}