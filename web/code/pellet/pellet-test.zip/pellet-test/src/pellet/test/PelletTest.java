package pellet.test;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.LinkedList;

import org.mindswap.pellet.KBLoader;
import org.mindswap.pellet.KRSSLoader;
import org.mindswap.pellet.KnowledgeBase;
import org.mindswap.pellet.PelletOptions;
import org.mindswap.pellet.jena.JenaLoader;
import org.mindswap.pellet.jena.ModelExtractor;
import org.mindswap.pellet.jena.PelletReasonerFactory;
import org.mindswap.pellet.jena.ModelExtractor.StatementType;
import org.mindswap.pellet.taxonomy.printer.ClassTreePrinter;
import org.mindswap.pellet.taxonomy.printer.TaxonomyPrinter;
import org.mindswap.pellet.utils.SetUtils;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLException;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyChange;

import android.app.Activity;
import android.os.Bundle;
import aterm.ATermAppl;

import com.clarkparsia.modularity.IncrementalClassifier;
import com.clarkparsia.modularity.OntologyDiff;
import com.clarkparsia.modularity.io.IncrementalClassifierPersistence;
import com.clarkparsia.pellet.owlapiv3.OWLAPILoader;
import com.clarkparsia.pellet.owlapiv3.OWLClassTreePrinter;
import com.hp.hpl.jena.ontology.OntClass;
import com.hp.hpl.jena.ontology.OntModel;
import com.hp.hpl.jena.rdf.model.InfModel;
import com.hp.hpl.jena.rdf.model.Model;
import com.hp.hpl.jena.rdf.model.ModelFactory;
import com.hp.hpl.jena.rdf.model.RDFReaderF;
import com.hp.hpl.jena.rdf.model.Resource;
import com.hp.hpl.jena.reasoner.Reasoner;
import com.hp.hpl.jena.reasoner.ValidityReport;
import com.hp.hpl.jena.shared.NoReaderForLangException;
import com.hp.hpl.jena.vocabulary.RDFS;

public class PelletTest extends Activity {

	private String path;
	private String path2;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pellet_test);

		path = "file:///" + getFilesDir().getPath() + "/";
		path2 = getFilesDir().getPath() + "/";
		
		new Thread(new Runnable() {

			public void run() {
				// testOWL_default();
				// testOWL_ont();

				testOWLAPIv3_extractInfs();
			}
		}).start();
	}

	public static void testOWL_default() {
		System.out.println("Results with plain RDF Model");
		System.out.println("----------------------------");
		System.out.println();

		// ontology that will be used
		String ont = "http://protege.cim3.net/file/pub/ontologies/koala/koala.owl#";
		String ns = "http://protege.stanford.edu/plugins/owl/owl-library/koala.owl#";

		// create Pellet reasoner
		Reasoner reasoner = PelletReasonerFactory.theInstance().create();

		// create an empty model
		Model emptyModel = ModelFactory.createDefaultModel();

		// create an inferencing model using Pellet reasoner
		InfModel model = ModelFactory.createInfModel(reasoner, emptyModel);

		// read the file
		model.read(ont);

		// print validation report
		ValidityReport report = model.validate();
		printIterator(report.getReports(), "Validation Results");

		// print superclasses
		Resource c = model.getResource(ns + "MaleStudentWith3Daughters");
		printIterator(model.listObjectsOfProperty(c, RDFS.subClassOf),
				"All super classes of " + c.getLocalName());

		System.out.println();
	}

	public static void testOWL_ont() {
		System.out.println("Results with OntModel");
		System.out.println("---------------------");
		System.out.println();

		// ontology that will be used
		String ont = "http://protege.cim3.net/file/pub/ontologies/koala/koala.owl#";
		String ns = "http://protege.stanford.edu/plugins/owl/owl-library/koala.owl#";

		// create an empty ontology model using Pellet spec
		OntModel model = ModelFactory
				.createOntologyModel(PelletReasonerFactory.THE_SPEC);

		// read the file
		model.read(ont);

		// print validation report
		ValidityReport report = model.validate();
		printIterator(report.getReports(), "Validation Results");

		// print superclasses using the utility function
		OntClass c = model.getOntClass(ns + "MaleStudentWith3Daughters");
		printIterator(c.listSuperClasses(),
				"All super classes of " + c.getLocalName());
		// OntClass provides function to print *only* the direct subclasses
		printIterator(c.listSuperClasses(true),
				"Direct superclasses of " + c.getLocalName());

		System.out.println();
	}

	public static void printIterator(Iterator<?> i, String header) {
		System.out.println(header);
		for (int c = 0; c < header.length(); c++)
			System.out.print("=");
		System.out.println();

		if (i.hasNext()) {
			while (i.hasNext())
				System.out.println(i.next());
		} else
			System.out.println("<EMPTY>");

		System.out.println();
	}

	public void testOWLAPIv3_classify() {
		KBLoader loader = getLoader("OWLAPIv3");
		KnowledgeBase kb = loader.createKB(path + "owlDemo-consistent.owl");

		System.out.println("consistent? " + kb.isConsistent());

		kb.classify();

		TaxonomyPrinter<ATermAppl> printer = new ClassTreePrinter();
		printer.print(kb.getTaxonomy());
	}

	private File saveFile;
	
	// NOTE re-using the same IncrementalClassifier instance doesn't seem to
	// work
	public void testOWLAPIv3_incrClassify() {
		saveFile = new File(path2 + "classifier_cache.owl");
		
		OWLOntology ontology = getOntology(path + "owlDemo-consistent-baseline.owl");

		// - baseline
		System.out.println("> baseline");

		IncrementalClassifier incrClass = createIncrementalClassifier(ontology);
		classify(incrClass);

		persistIncrementalClassifier(incrClass);

		// - single
		System.out.println("\n\n> single");

		// updated ontology; also needs to include original baseline ontology
		OWLOntology ontology2 = getOntology(path + "owlDemo-consistent.owl");

		incrClass = createIncrementalClassifier(ontology2);

		// (when trying to re-use same classifier instance)
		// OntologyDiff ontologyDiff = OntologyDiff.diffAxioms(
		// ontology.getAxioms(), ontology2.getAxioms());
		// incrClass.ontologiesChanged(new LinkedList<OWLOntologyChange>(
		// ontologyDiff.getChanges(ontology2)));

		classify(incrClass);
	}

	private void classify(IncrementalClassifier incrClass) {
		System.out.println("classified? " + incrClass.isClassified());

		// if (!incrClass.isClassified()) {
		boolean isConsistent = incrClass.isConsistent();

		if (!isConsistent)
			System.out.println("ontology is inconsistent!");
		else
			incrClass.classify();
		// }

		TaxonomyPrinter<OWLClass> printer = new OWLClassTreePrinter();
		printer.print(incrClass.getTaxonomy());
	}

	private OWLOntology getOntology(String path) {
		OWLAPILoader loader = (OWLAPILoader) getLoader("OWLAPIv3");
		loader.parse(path);

		return loader.getOntology();
	}

	private void persistIncrementalClassifier(
			IncrementalClassifier incrementalClassifier) {
		System.out.println("saving the state of the classifier to " + saveFile);

		try {
			// doesn't work
			if (!saveFile.exists())
				saveFile.createNewFile();
			FileOutputStream outputStream = new FileOutputStream(saveFile,
					false);

			IncrementalClassifierPersistence.save(incrementalClassifier,
					outputStream);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private IncrementalClassifier createIncrementalClassifier(
			OWLOntology ontology) {

		IncrementalClassifier result = null;

		// first try to restore the classifier from the file (if one exists)
		if (saveFile.exists()) {
			result = loadIncrementalClassifier(ontology);
		}

		// if it was not possible to restore the classifier, create one from
		// scratch
		else {
			result = new IncrementalClassifier(ontology);
		}

		result.getReasoner()
				.getKB()
				.setTaxonomyBuilderProgressMonitor(
						PelletOptions.USE_CLASSIFICATION_MONITOR.create());

		return result;
	}

	private IncrementalClassifier loadIncrementalClassifier(OWLOntology ontology) {
		try {
			System.out.println("loading the state of the classifier from "
					+ saveFile);

			FileInputStream inputStream = new FileInputStream(saveFile);
			IncrementalClassifier result = IncrementalClassifierPersistence
					.load(inputStream, ontology);

			// check whether anything changed in the ontology in the time
			// between the incremental classifier
			// was persisted and the current time
			OntologyDiff ontologyDiff = OntologyDiff.diffAxioms(
					result.getAxioms(), ontology.getAxioms());

			System.out.println("diff: (# " + ontologyDiff.getDiffCount()
					+ "): " + ontologyDiff.getChanges(ontology));

			if (ontologyDiff.getDiffCount() > 0) {
				result.ontologiesChanged(new LinkedList<OWLOntologyChange>(
						ontologyDiff.getChanges(ontology)));
			}

			return result;

		} catch (IOException e) {
			e.printStackTrace();

			return null;

		} catch (OWLException e) {
			e.printStackTrace();

			return null;
		}
	}
	
	private EnumSet<StatementType> selector;
	
	private void testOWLAPIv3_extractInfs() {
		mapStatementTypes();
		
		OWLAPILoader loader = (OWLAPILoader) getLoader("OWLAPIv3");
		KnowledgeBase kb = loader.createKB(path + "owlDemo-consistent.owl");

		ModelExtractor extractor = new ModelExtractor(kb);
		extractor.setSelector(selector);

		Model extracted = ModelFactory.createDefaultModel();

		if (SetUtils.intersects(selector,
				ModelExtractor.StatementType.ALL_CLASS_STATEMENTS)) {
			extractor.extractClassModel(extracted);
		}

		if (SetUtils.intersects(selector,
				ModelExtractor.StatementType.ALL_PROPERTY_STATEMENTS)) {
			extractor.extractPropertyModel(extracted);
		}

		if (SetUtils.intersects(selector,
				ModelExtractor.StatementType.ALL_INDIVIDUAL_STATEMENTS)) {
			extractor.extractIndividualModel(extracted);
		}

		ByteArrayOutputStream bOut = new ByteArrayOutputStream();
		extracted.write(bOut,"N3");
		
		String str = new String(bOut.toByteArray());
		String[] subStrs = str.split("\n");
		for (String subStr : subStrs)
			System.out.println(subStr);
	}
	
	private void mapStatementTypes() {
		String statements = "";
		String[] list = statements.split(" ");

		// for( int i = 0; i < list.length; i++ ) {
		// String l = list[i];
		// if( l.equalsIgnoreCase( "DefaultStatements" ) )
		selectorAddAll(StatementType.DEFAULT_STATEMENTS);
		// else if( l.equalsIgnoreCase( "AllStatements" ) )
		selectorAddAll(StatementType.ALL_STATEMENTS);
		// else if( l.equalsIgnoreCase( "AllStatementsIncludingJena" ) )
		selectorAddAll(StatementType.ALL_STATEMENTS_INCLUDING_JENA);
		// else if( l.equalsIgnoreCase( "AllClass" ) )
		selectorAddAll(StatementType.ALL_CLASS_STATEMENTS);
		// else if( l.equalsIgnoreCase( "AllIndividual" ) )
		selectorAddAll(StatementType.ALL_INDIVIDUAL_STATEMENTS);
		// else if( l.equalsIgnoreCase( "AllProperty" ) )
		selectorAddAll(StatementType.ALL_PROPERTY_STATEMENTS);
		// else if( l.equalsIgnoreCase( "ClassAssertion" ) )
		selectorAdd(StatementType.ALL_INSTANCE);
		// else if( l.equalsIgnoreCase( "ComplementOf" ) )
		selectorAdd(StatementType.COMPLEMENT_CLASS);
		// else if( l.equalsIgnoreCase( "DataPropertyAssertion" ) )
		selectorAdd(StatementType.DATA_PROPERTY_VALUE);
		// else if( l.equalsIgnoreCase( "DifferentIndividuals" ) )
		selectorAdd(StatementType.DIFFERENT_FROM);
		// else if( l.equalsIgnoreCase( "DirectClassAssertion" ) )
		selectorAdd(StatementType.DIRECT_INSTANCE);
		// else if( l.equalsIgnoreCase( "DirectSubClassOf" ) )
		selectorAdd(StatementType.DIRECT_SUBCLASS);
		// else if( l.equalsIgnoreCase( "DirectSubPropertyOf" ) )
		selectorAdd(StatementType.DIRECT_SUBPROPERTY);
		// else if( l.equalsIgnoreCase( "DisjointClasses" ) )
		selectorAdd(StatementType.DISJOINT_CLASS);
		// else if( l.equalsIgnoreCase( "DisjointProperties" ) )
		selectorAdd(StatementType.DISJOINT_PROPERTY);
		// else if( l.equalsIgnoreCase( "EquivalentClasses" ) )
		selectorAdd(StatementType.EQUIVALENT_CLASS);
		// else if( l.equalsIgnoreCase( "EquivalentProperties" ) )
		selectorAdd(StatementType.EQUIVALENT_PROPERTY);
		// else if( l.equalsIgnoreCase( "InverseProperties" ) )
		selectorAdd(StatementType.INVERSE_PROPERTY);
		// else if( l.equalsIgnoreCase( "ObjectPropertyAssertion" ) )
		selectorAdd(StatementType.OBJECT_PROPERTY_VALUE);
		// else if( l.equalsIgnoreCase( "PropertyAssertion" ) )
		selectorAddAll(StatementType.PROPERTY_VALUE);
		// else if( l.equalsIgnoreCase( "SameIndividual" ) )
		selectorAdd(StatementType.SAME_AS);
		// else if( l.equalsIgnoreCase( "SubClassOf" ) )
		selectorAdd(StatementType.ALL_SUBCLASS);
		// else if( l.equalsIgnoreCase( "SubPropertyOf" ) )
		selectorAdd(StatementType.ALL_SUBPROPERTY);
		// }

		if (selector == null)
			selector = StatementType.DEFAULT_STATEMENTS;
	}

	private void selectorAddAll(EnumSet<StatementType> types) {
		if (selector == null)
			selector = types;
		else
			selector.addAll(types);
	}

	private void selectorAdd(StatementType type) {
		if (selector == null)
			selector = EnumSet.of(type);
		else
			selector.add(type);
	}

	private static RDFReaderF READER_FACTORY = ModelFactory
			.createDefaultModel();

	private boolean ignoreImports = true;
	private String inputFormat = "RDF/XML";

	protected KBLoader getLoader(String loaderName) {
		KBLoader loader = null;

		if (loaderName.equalsIgnoreCase("Jena"))
			loader = new JenaLoader();
		else if (loaderName.equalsIgnoreCase("OWLAPIv3")
				|| loaderName.equalsIgnoreCase("OWLAPI"))
			loader = new OWLAPILoader();
		else if (loaderName.equalsIgnoreCase("KRSS"))
			loader = new KRSSLoader();

		loader.setIgnoreImports(ignoreImports);
		if (loader instanceof JenaLoader) {
			inputFormat = inputFormat.toUpperCase();

			try {
				if (inputFormat != null) {
					READER_FACTORY.getReader(inputFormat.toUpperCase());

					((JenaLoader) loader).setInputFormat(inputFormat);
				}
			} catch (NoReaderForLangException e) {
				e.printStackTrace();
			}
		}

		return loader;
	}
}
