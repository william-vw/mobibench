/**
 * Copyright 2016 William Van Woensel

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
 * 
 * 
 * @author wvw
 * 
 */

package wvw.mobibench.auto;

import java.io.IOException;
import java.util.List;

import wvw.mobibench.devserv.server.handler.HandlerException;
import wvw.mobibench.devserv.server.handler.HandlerListener;
import wvw.mobibench.devserv.server.handler.RequestHandler;
import wvw.mobibench.devserv.server.http.HttpServer;
import wvw.mobibench.run.config.EntailmentServiceMatchConfig;
import wvw.mobibench.run.config.MatchDirections;
import wvw.mobibench.run.config.OWL2RLRunConfig;
import wvw.mobibench.run.config.OWLBuiltinRunConfig;
import wvw.mobibench.run.config.OWLDataset;
import wvw.mobibench.run.config.OWLScope;
import wvw.mobibench.run.config.RuleBasedServiceMatchConfig;
import wvw.utils.IOUtils;
import wvw.utils.log2.Log;
import wvw.utils.log2.target.SystemOutTarget;

public class AutoBenchmarkDeviceClient extends AutoBenchmark implements RequestHandler {

	private HttpServer server;

	// IMPORTANT update this IP address to the one displayed on the android app
	private String deviceAddress = "http://134.190.185.172:8082";

	private String localPath = "res/owl/";
	// IMPORTANT update this path to suit your setup
	private String remotePath = "C:/Users/William/git/mobile-benchmarks/MobiBenchEngineJS/www/res/owl/";

	public static void init() {
		Log.setTarget(new SystemOutTarget());
	}

	public static void main(String[] args) {
		init();

		AutoBenchmarkDeviceClient client = new AutoBenchmarkDeviceClient();
		client.run();
	}

	public AutoBenchmarkDeviceClient() {
		super(5000);

		server = new HttpServer(this, 8082);

		try {
			server.start();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void run() {
		run_OWL2RL(genConfig_OWL2RL());
		// run_OWLBuiltin(genConfig_OWLBuiltin());
		// run_ruleBasedServiceMatching(genConfig_ruleBasedServiceMatching());
	}

	protected List<OWL2RLRunConfig> genConfig_OWL2RL() {
		OWL2RLRunConfig config = new OWL2RLRunConfig();

		config.setEngine("androjena");

		config.setNrRuns(1);
		config.setWarmupRun(false);

		config.setDumpHeap(false);

		config.setMainFlow("frequent");

		config.setSubFlow("load_data_exec_rules");
		// config.setSubFlow("load_rules_data_exec");

		config.setTask("ontology_inference");
		config.setSubTask("owl2rl");

		// - some example setups

		// config.select("entailed");
		// config.addDataset(new OWLDataset("ore-small", 0, 0));

		config.select(new String[] { "entailed", "domain-based" });
		config.addDataset(new OWLDataset("ore-small", 0, 0));

		// config.select("valid", "gener-rules");
		// config.addDataset(new OWLDataset("ore-small", "mat-inst", 0, 0));

		// config.select(new String[] { "inf-inst", "entailed", "domain-based"
		// });
		// config.addDataset(new OWLDataset("ore-small", "mat-ont", 0, 0));

		config.setLocalPath(localPath);
		config.setRemotePath(remotePath);

		config.setOutputInf(true);

		config.setConfTest(true);
		config.setConfTarget("full");

		return config.genAtomConfigs();
	}

	protected OWLBuiltinRunConfig genConfig_OWLBuiltin() {
		OWLBuiltinRunConfig config = new OWLBuiltinRunConfig();

		config.setEngine("hermit");

		config.setNrRuns(1);
		config.setWarmupRun(false);

		config.setDumpHeap(false);

		config.setMainFlow("frequent");

		config.setTask("ontology_inference");
		config.setSubTask("builtin");

		config.addScope(new OWLScope("full"));
		config.addDataset(new OWLDataset("ore-small", 0, 10));

		config.setLocalPath(localPath);
		config.setRemotePath(remotePath);

		// config.setOutputInf(true);

		// config.setConfTest(true);
		// config.setConfTarget(new OWLScope("full"));

		return config;
	}

	protected EntailmentServiceMatchConfig genConfig_entailmentServiceMatching() {
		EntailmentServiceMatchConfig config = new EntailmentServiceMatchConfig();

		config.setEngine("hermit");

		config.setNrRuns(1);
		config.setWarmupRun(false);

		config.setDumpHeap(false);

		config.setMainFlow("frequent");

		config.setTask("service_match");
		config.setSubTask("entailment");

		config.setDirections(MatchDirections.GOAL_SERVICE);

		config.addDataset(new OWLDataset("precond"));

		return config;
	}

	protected RuleBasedServiceMatchConfig genConfig_ruleBasedServiceMatching() {
		RuleBasedServiceMatchConfig config = new RuleBasedServiceMatchConfig();

		config.setEngine("rdfstore_js");

		config.setNrRuns(1);
		config.setWarmupRun(false);

		config.setDumpHeap(false);

		config.setMainFlow("frequent");

		config.setSubFlow("load_data_exec_rules");
		// config.setSubFlow("load_rules_data_exec");

		config.setTask("service_match");
		config.setSubTask("rule_based");

		config.setDirections(MatchDirections.GOAL_SERVICE);
		// config.addSelection("inf");

		// config.setOutputInf(true);

		config.addDataset(new OWLDataset("precond"));

		return config;
	}

	protected void doBenchmark(String config) {
		try {
			IOUtils.sendPost(deviceAddress + "/run", config);

		} catch (IOException e) {
			Log.e("error contacting device", e);
		}
	}

	public void handle(String uri, HandlerListener listener) throws HandlerException {
		handle(uri, null, listener);
	}

	public void handle(String uri, String data, HandlerListener listener) throws HandlerException {

		benchmarkNext();
	}

	protected void allDone() {
		// try {
		// Thread.sleep(1000);
		//
		// } catch (InterruptedException e) {
		// e.printStackTrace();
		// }

		server.stop();
	}
}
