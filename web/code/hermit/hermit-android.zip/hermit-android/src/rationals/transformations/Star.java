/*
 * (C) Copyright 2001 Arnaud Bailly (arnaud.oqube@gmail.com),
 *     Yves Roos (yroos@lifl.fr) and others.
 *
 * Licensed under the Apache License, Version 2.0 (the License);
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an AS IS BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package rationals.transformations;

import rationals.Automaton;
import rationals.NoSuchStateException;
import rationals.State;
import rationals.Transition;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Compute the kleene-star closure of an automaton.
 * 
 * @author nono
 * @version $Id: Star.java 2 2006-08-24 14:41:48Z oqube $
 */
public class Star implements UnaryTransformation {
    public Automaton transform(Automaton a) {
        if (a.delta().size() == 0)
            return Automaton.epsilonAutomaton();
        Automaton b = new Automaton();
        State ni = b.addState(true, true);
        State nt = b.addState(true, true);
        Map map = new HashMap();
        Iterator i = a.states().iterator();
        while (i.hasNext()) {
            map.put(i.next(), b.addState(false, false));
        }
        i = a.delta().iterator();
        while (i.hasNext()) {
            Transition t = (Transition) i.next();
            try {
                b.addTransition(new Transition((State) map.get(t.start()), t
                        .label(), (State) map.get(t.end())));
            } catch (NoSuchStateException x) {
            }
            if (t.start().isInitial() && t.end().isTerminal()) {
                try {
                    b.addTransition(new Transition(ni, t.label(), nt));
                    b.addTransition(new Transition(nt, t.label(), ni));
                } catch (NoSuchStateException x) {
                }
            } else if (t.start().isInitial()) {
                try {
                    b.addTransition(new Transition(ni, t.label(), (State) map
                            .get(t.end())));
                    b.addTransition(new Transition(nt, t.label(), (State) map
                            .get(t.end())));
                } catch (NoSuchStateException x) {
                }
            } else if (t.end().isTerminal()) {
                try {
                    b.addTransition(new Transition((State) map.get(t.start()),
                            t.label(), nt));
                    b.addTransition(new Transition((State) map.get(t.start()),
                            t.label(), ni));
                } catch (NoSuchStateException x) {
                }
            }
        }
        return b;
    }
}