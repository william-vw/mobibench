package jablah.awt;

public class Point {
	/**
	 * The X coordinate of this <code>Point</code>. If no X coordinate is set it
	 * will default to 0.
	 *
	 * @serial
	 * @see #getLocation()
	 * @see #move(int, int)
	 * @since 1.0
	 */
	public int x;

	/**
	 * The Y coordinate of this <code>Point</code>. If no Y coordinate is set it
	 * will default to 0.
	 *
	 * @serial
	 * @see #getLocation()
	 * @see #move(int, int)
	 * @since 1.0
	 */
	public int y;

	/**
	 * Constructs and initializes a point at the origin (0,&nbsp;0) of the
	 * coordinate space.
	 * 
	 * @since 1.1
	 */
	public Point() {
		this(0, 0);
	}

	/**
	 * Constructs and initializes a point with the same location as the
	 * specified <code>Point</code> object.
	 * 
	 * @param p
	 *            a point
	 * @since 1.1
	 */
	public Point(Point p) {
		this(p.x, p.y);
	}

	/**
	 * Constructs and initializes a point at the specified {@code (x,y)}
	 * location in the coordinate space.
	 * 
	 * @param x
	 *            the X coordinate of the newly constructed <code>Point</code>
	 * @param y
	 *            the Y coordinate of the newly constructed <code>Point</code>
	 * @since 1.0
	 */
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @since 1.2
	 */
	public double getX() {
		return x;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * @since 1.2
	 */
	public double getY() {
		return y;
	}

	/**
	 * Returns the hashcode for this <code>Point2D</code>.
	 * 
	 * @return a hash code for this <code>Point2D</code>.
	 */
	public int hashCode() {
		long bits = java.lang.Double.doubleToLongBits(getX());
		bits ^= java.lang.Double.doubleToLongBits(getY()) * 31;
		return (((int) bits) ^ ((int) (bits >> 32)));
	}
}
