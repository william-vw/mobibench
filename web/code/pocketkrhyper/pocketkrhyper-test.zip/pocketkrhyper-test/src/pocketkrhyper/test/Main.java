/*
 * Main.java
 *
 * Created on 2. September 2005, 14:34
 *
 * Pocket KrHyper - 
 * an automated theorem proving library for the 
 * Java 2 Platform, Micro Edition (J2ME)
 * Copyright (C) 2005 Thomas Kleemann and Alex Sinner
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. 
 * See the GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA 
 *
 */

package pocketkrhyper.test;

import pocketkrhyper.logic.firstorder.KnowledgeBase;
import pocketkrhyper.reasoner.ProofNotFoundException;
import pocketkrhyper.reasoner.Reasoner;
import pocketkrhyper.reasoner.krhyper.KrHyper;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;

/**
 *
 * @author sinner
 */
public class Main {
    
    private KnowledgeBase kb;
    private Reasoner reasoner;

    private final static String version = "0.8";
    private Main(){
        kb = new KnowledgeBase();
        reasoner = new KrHyper();
    }
    

    private final void openTPTPProblem(InputStream in) throws IOException {
        kb = TptpParser.parse(in);
    }
    
    private final String solveProblem(int minTermWeight, int maxTermWeight, int timeout){
        reasoner.setKnowledgeBase(kb);
        StringBuffer text = new StringBuffer();
        try {
            long currentTime = System.currentTimeMillis();
            boolean model = reasoner.reason(minTermWeight, maxTermWeight, timeout);
            long time = System.currentTimeMillis() - currentTime;
            if (model){
                text.append("% Model found in "+time+ "ms:\n");
                for (Enumeration e = reasoner.getModel().elements() ; e.hasMoreElements() ; ){
                    text.append(e.nextElement().toString());
                    text.append(".\n");
                }
            } else {
                text.append("% Refutation found in "+time+ "ms.\n");
            }
        } catch (ProofNotFoundException ex){
            text.append("% No Solution found. (Timeout)\n");
        } catch (Error err){
            text.append("% No Solution found. (Out of Memory)\n");
        } finally{
            reasoner.interruptReasoner();
        }
        kb = null;
        return text.toString();
    }
        
    private static final String getUsage(){
        return "Usage:"+
                "\njava -jar PocketKrHyper.jar [-minTermWeight n] [-maxTermWeight m] [-timeout ms] PROTEINproblem" +
                "\nwhere \n\t n is the minimum term weight (default 2)" +
                "\n\t m is the maximum term weight (has to be 0 or > n). 0 means no upper bound is given. Default 0." +
                "\n\t ms the timeout for the proof procedure in ms. Default 1000." +
                "\n\t PROTEINproblem - a deduction problem in PROTEIN syntax.\n";
                
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int minTermWeight = 2;
        int maxTermWeight = 0;
        int timeout = 1000;
        String fileName = null;
        InputStream in = null;
        for (int i = 0 ; i < args.length ; i++){
            if (args[i].equalsIgnoreCase("-minTermWeight")){
                i++;
                try {
                    minTermWeight = Integer.parseInt(args[i]);
                } catch (Exception ex){
                    System.err.println(getUsage());
                    System.exit(-1);
                }
            } else if (args[i].equalsIgnoreCase("-maxTermWeight")){
                i++;
                try {
                    maxTermWeight = Integer.parseInt(args[i]);
                } catch (Exception ex){
                    System.err.println(getUsage());
                    System.exit(-1);
                }
            } else if (args[i].equalsIgnoreCase("-timeout")){
                i++;
                try {
                    timeout = Integer.parseInt(args[i]);
                } catch (Exception ex){
                    System.err.println(getUsage());
                    System.exit(-1);
                }
            } else {
                fileName = args[i];
            }
        }
        Main app = new Main();
        try {
            if (fileName != null){
                in = new FileInputStream(fileName);
            } else {
                    System.err.println(getUsage());
                    System.exit(-1);                
            }
        } catch (FileNotFoundException ex){
            System.err.println("Could not open file " + fileName);
            System.exit(-1);
        }
        try {
            app.openTPTPProblem(in);
        } catch (IOException ex){
            System.err.println("Could not read file " + fileName);
            System.exit(-1);
        }
        
        System.out.println("% Running Pocket KrHyper with the following parameters:" +
                "\n% Version: " + version +
                "\n% Input File: " + fileName +
                "\n% minTermWeight: " + minTermWeight +
                "\n% maxTermWeight: " + maxTermWeight +
                "\n% timeout: " + timeout + '\n');
        System.out.println(app.solveProblem(minTermWeight, maxTermWeight, timeout));
        System.exit(1);
    }
    
}
